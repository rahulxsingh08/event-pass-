# CampusPass

**A campus event discovery and seat-booking prototype.** Students can find events, choose seats, enter attendee details, and view demo tickets. Event staff can review sample UPI references and issue demo QR tickets.

> [!CAUTION]
> This repository is a front-end demo, not a production ticketing service. Student accounts, bookings, approvals, QR codes, and check-in use browser storage. They can be changed with browser developer tools. Do not use demo QR codes for real entry or store real student/payment information in the demo.

## Preview

The project includes an optional self-contained `portable.html` for a quick local preview, plus the editable Vite source. The preview file is generated from the source and is rebuilt with `npm run build:portable`.

The repository includes a GitHub Pages workflow for the demo. After the first push to `main`, enable **Settings → Pages → GitHub Actions** if GitHub has not enabled it automatically. The workflow publishes the front-end demo only; it does not make the demo data or login secure.

For a detailed presentation script, architecture explanation, and judge Q&A, see [PRESENTATION_GUIDE.md](PRESENTATION_GUIDE.md). For the demo-versus-production threat model, see [SECURITY_MODEL.md](SECURITY_MODEL.md).

## Features

- Event discovery, search, event detail pages, and an interactive seat map
- Two-minute demo holds, with a countdown and held-seat display
- Student registration and returning-student access using the same Gmail and college roll number
- Roll number format validation: `2453` followed by exactly eight digits
- Attendee name and roll number for every seat in a group booking
- Manual UPI reference review flow; no payment is collected
- Per-seat demo QR codes shown after confirmation, plus local duplicate check-in feedback
- Separate student and admin experiences
- Supabase-oriented schema for profiles, events, seats, holds, bookings, payment records, and one-time ticket redemption
- Portable, single-file preview for offline UI exploration

## Run locally

Requirements: Node.js 20 or newer and npm.

```bash
npm install
npm run dev
```

Open the local URL printed by Vite. On Windows, you can also double-click `start-campuspass.bat`.

To rebuild the single-file preview:

```bash
npm run build:portable
```

Then open `portable.html`. Do not open `index.html` directly with `file://`; it is the Vite source entry and needs a dev server.

## Demo accounts and data

- **Student:** create a profile with a name, Gmail address, and roll number. On later visits, choose **Already registered? Sign in** and enter the same Gmail and roll number.
- **Admin:** username `admin`, password `admin`.
- Demo records are saved in the current browser's local storage. Clearing site data removes them. Different devices do not share accounts, seats, or bookings.
- The admin password is intentionally a hard-coded demo credential. Local role checks are not authentication or authorization.
- Students can claim an unregistered roll number in demo mode. The format check does not verify enrollment.

## Booking flow

```mermaid
flowchart LR
  A[Student profile] --> B[Choose event and seats]
  B --> C[Two-minute local hold]
  C --> D[Enter attendee per seat]
  D --> E{Event price}
  E -->|Free| F[Demo booking confirmed]
  E -->|Paid| G[Submit sample UPI reference]
  G --> H[Admin manually reviews demo request]
  H -->|Approve| I[Demo QR per seat]
  F --> I
  I --> J[Local demo check-in]
```

For a real deployment, each state transition must be checked and saved on the server. The browser must not decide that a payment is paid, a ticket is valid, a seat is owned, or an account is an admin.

## Architecture

| Area | Current demo | Production direction |
| --- | --- | --- |
| UI | React 18, Vite, custom CSS, Lucide icons | Keep the UI; connect actions to authenticated server APIs |
| Student identity | Browser form and local roll/email map | Supabase Google OAuth plus trusted college roster validation |
| Admin | `admin` / `admin` demo form and client-side role | Server-verified `profiles.role`; admin-only database policies |
| Seats | Local storage, with Web Locks where supported | Atomic database seat-hold RPC and unique seat constraints |
| Bookings | Browser local storage | Transactional server-side booking creation and ownership checks |
| Payment | Sample UPI reference, manual demo approval | Verify the actual college account credit; never trust a client claim |
| QR tickets | Random demo token generated in the browser | Server-issued high-entropy bearer token; store only a hash server-side |
| Check-in | Local lookup and duplicate-use feedback | Admin-only atomic redemption RPC; reject invalid, unpaid, cancelled, or used tickets |

### Source layout

```text
src/App.jsx             React screens and demo booking flows
src/style.css           Responsive visual design
src/main.jsx            React app entry point
supabase/schema.sql     RLS, database tables, seat holds, ticket redemption foundation
PRESENTATION_GUIDE.md   Project walkthrough and judge Q&A
SECURITY_MODEL.md       Threats, demo limits, and production controls
```

## Production security checklist

The SQL file is a starting point; the current UI does **not** call all of its protected database functions.

1. Configure Supabase Auth with Google OAuth and deploy over HTTPS.
2. Verify student roll numbers against a trusted college roster; format validation alone proves nothing about enrollment.
3. Create bookings and seat rows inside a trusted, transactional server function. Use the atomic `hold_seats` RPC for shared seat holds.
4. Assign admin roles only through trusted server or database administration. Never accept a role supplied by the browser.
5. Verify UPI receipts against the official college account before marking payment paid.
6. Issue random ticket tokens server-side after approval, store only their SHA-256 hashes, and return the raw token only to the ticket owner.
7. Scan QR content through the admin app and call `redeem_ticket`; that function checks payment and approval and marks the ticket used in one transaction.
8. Add rate limits, audit logs, cancellation/refund rules, privacy notice, backups, and an incident/support process.

Never place a Supabase service-role key, signing secret, payment-provider secret, or other private credential in a `VITE_*` variable or browser bundle. `.env.example` contains only the public project URL and publishable/anon key placeholders.

## REA and design notes

CampusPass is an original implementation. REA (Reverse Engineer Anything) was used as a reference for an evidence-first way to inspect application behavior; no REA source or third-party booking-site code is bundled here. The current repository is a normal React source project, so its behavior can be reviewed directly in `src/App.jsx` and `supabase/schema.sql`.

## License

No reuse license has been selected for this project yet. Contact the author before reusing or redistributing the source.
